# juleEvent AS

## logg over juleEvent prosjektet:

### Fredeg 29 November 2024

idag har vi begynt på juleEvent prosjektet.

### fredag 6 desember 2024

idag lagde jeg klar divene for hvrdan det skal se ut.